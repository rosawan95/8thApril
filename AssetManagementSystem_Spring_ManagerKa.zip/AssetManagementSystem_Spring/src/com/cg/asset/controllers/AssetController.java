package com.cg.asset.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.asset.dtos.*;
import com.cg.asset.exception.*;
import com.cg.asset.dtos.Asset;
import com.cg.asset.dtos.User;
import com.cg.asset.exception.AssetException;
import com.cg.asset.services.*;

@Controller
public class AssetController {

	private IAssetServices services;

	@Resource(name="assetService")
	public void setAssetServices(IAssetServices services){
		this.services = services;
	}
	

	@RequestMapping("login.do")
	public ModelAndView getEmpAddFormPage(){
		ModelAndView model = new ModelAndView("login");
		return model;
	}
	
	
	@RequestMapping("authenticate.do")
	public ModelAndView submitEmpAddForm(
			HttpSession session, HttpServletRequest request ,
										@RequestParam("userName") String uname,
										@RequestParam("password") String password){
		ModelAndView model =new ModelAndView();       //@ModelAttribute is used as object comes from form. 
		session = request.getSession(true);
		
		List<Integer> myList = new ArrayList<Integer>();
		
			System.out.println("username  = "+uname);
			System.out.println("password  = "+password);
			
			try {
				myList= services.authenticate(uname, password);
				System.out.println("usertype = "+myList);
				int userType = myList.get(0);
				if (userType == 1)
				{	
					session.setAttribute("userName", uname);
					System.out.println("Admin authenticated successfully");
					model.setViewName("adminHomePage");		
					//model.addObject("userName",uname);
				}
				else if(userType == 2)
				{	
					System.out.println("Manager authenticated successfully");
					
					int mgrId = myList.get(1);
					System.out.println(" EmployeeId of manager is = "+mgrId);
					model.setViewName("managerHomePage");
					session.setAttribute("userName", uname);
					session.setAttribute("mgrId", mgrId);
					//model.addObject("empId",empId);
					//model.addObject("userName",uname);
					
				}else{
					model.setViewName("login");
					model.addObject("errorMsg","Incorrect UserName OR Password");
				}
			} catch (AssetException e) {
				System.out.println("Login Failed. Incorrect UserName");
				model.setViewName("login");
				model.addObject("errorMsg","Login Failed. Incorrect UserName");
			}
			return model;

	}
	
	@RequestMapping("createAssetRequestData.do")
	public ModelAndView createAssetRequestData(HttpSession session, HttpServletRequest request){
		ModelAndView model =new ModelAndView();
		List<Employee> empNames = new ArrayList<Employee>();
		
		session = request.getSession(false);
		int mgrId= (int) session.getAttribute("mgrId");
		System.out.println(mgrId);
		//int mgrId = (int) session.getAttribute("mgrId");
		
		try {
			System.out.println("in try");
			empNames = services.getAvailableEmployees(mgrId);
			System.out.println("Available Employees"+empNames);
			List<Asset> availAssetsDetail= services.getAssetDetailsListAdmin();
			System.out.println(availAssetsDetail);
			
			//session.setAttribute("availableEmps", empNames);
			//session.setAttribute("availAssetsDetail", availAssetsDetail);
			
			model.addObject("availableEmps", empNames);
			model.addObject("availAssetsDetail", availAssetsDetail );
			model.addObject("request", new Request()); 
			model.setViewName("requestForm");
		} catch (AssetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return model;
		
	}
	
	
	@RequestMapping("showAssets.do")
	public ModelAndView getshowAssetsPage(){
		
		ModelAndView model = new ModelAndView("showAssets");
		try {
			
			List<Asset> assetList = services.getAssetDetailsListAdmin();
			model.addObject("asset", assetList);
		
		} catch (AssetException e) {
			e.printStackTrace();
		}
		return model;
	}
	
	
	@RequestMapping("logout.do")
	public ModelAndView logout(){
		
		ModelAndView model = new ModelAndView("login");	
		return model;
	}
	
	
	
	
	
}
